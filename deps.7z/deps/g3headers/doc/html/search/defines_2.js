var searchData=
[
  ['npc_5flocal_5fid_5fplayer',['NPC_LOCAL_ID_PLAYER',['../npc_8h.html#ab4692e50617371e18f27b923208ee5f8',1,'npc.h']]],
  ['npc_5fstate_5fid_5fmax',['NPC_STATE_ID_MAX',['../npc_8h.html#a7dd07461c860467bd742f6ce3e172770',1,'npc.h']]]
];
