var searchData=
[
  ['nick',['nick',['../structPokemonBase.html#a65615e92b48ebb2e2dee7888d1e645c2',1,'PokemonBase']]],
  ['npc_5fstates',['npc_states',['../npc_8h.html#af2e2b04ea5fadcec56d8d611048a56d4',1,'npc.h']]]
];
