#ifndef POKEAGB_SAVE_H_
#define POKEAGB_SAVE_H_

#include "save/block.h"

#endif /* POKEAGB_SAVE_H_ */
