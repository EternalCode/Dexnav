#ifndef POKEAGB_GRAPHICS_H_
#define POKEAGB_GRAPHICS_H_

#include "graphics/background.h"
#include "graphics/palette.h"
#include "graphics/sprites.h"

#endif /* POKEAGB_GRAPHICS_H_ */
