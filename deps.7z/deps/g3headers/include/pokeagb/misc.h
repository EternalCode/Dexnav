#ifndef POKEAGB_MISC_H_
#define POKEAGB_MISC_H_

#include "misc/titlescreen.h"

#endif /* POKEAGB_MISC_H_ */
